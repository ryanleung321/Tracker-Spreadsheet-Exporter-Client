"use strict";

class project{
//name is name, sheetsURL is url of project spreadsheet, trackerURL is tracker url, daysActive is an array comprised of bools that keeps track of days active
	constructor(name, sheetsURL, trackerURL, daysActive){
		this.name = name;
		this.sheetsURL = sheetsURL;
		this.trackerURL = trackerURL;
		this.daysActive = daysActive;
	}
}

//generates additional input fields
function addInput(){
	//create the input item
	var textInput = document.createElement('input');

	//set radio button attributes
	textInput.setAttribute('type', 'text');
	textInput.setAttribute('size', '35');
	textInput.setAttribute('name', 'text');

	//group the buttons into a class
	textInput.setAttribute('class', 'newTextInput');

	//create a linebreak element
	var linebreak = document.createElement("br");

	//append elements to the html div
	document.getElementById('additionalFields').appendChild(textInput);
	document.getElementById('additionalFields').appendChild(linebreak);
}

//append values to storage
function appendToStorage(key, data){
    var old = localStorage.getItem(key);
    if(old === null) old = "";
    localStorage.setItem(key, old + data);
}

//append values to an array stored in localStorage
function appendToStoredArray(key, data){
	var array = JSON.parse(localStorage.getItem(key));
	array.push(data);
	localStorage.setItem(key, JSON.stringify(array));
	console.log(localStorage.getItem(key)); //should log json string of array
}

//invoked on submitButton click
function addProject() {
	//pull values by ID from html form
	var name = document.getElementById("projectName").value;
	var sheetsURL = document.getElementById("sheetsURL").value;
	var trackerURL = document.getElementById("trackerURL").value;

	//get checkbox elements by class name
	var inputElements = document.getElementsByClassName('dayCheckbox');

	//new array of days chosen
	var dayArray = new Array();
	for(var i=0; inputElements[i]; ++i){
		if(inputElements[i].checked){
        	dayArray[i] = true;
      	}
      	else{
      		dayArray[i] = false;
      	}
	}

	//creating the project object
	var newProject = new project(name, sheetsURL, trackerURL, dayArray);

	//append new project to projectList array
	appendToStoredArray('projectList', newProject);

	console.log(newProject); //should log newProject object
}

var urlCount = 0;

document.getElementById('addFieldButton').addEventListener('click', function(){
	urlCount += 1;
	var urlInt = urlCount.toString();
	var paragraph = document.createElement('P');
	document.getElementById('additionalFields').appendChild(document.createTextNode('url ' + urlInt + ':'));
	addInput();
});

//runs addProject on click
document.getElementById('submitButton').addEventListener('click', function(){
	//check for previous projectList entries, create one if none
	if (localStorage.getItem('projectList') === null){
		var arrayOfProjects = new Array();
		localStorage.setItem('projectList', JSON.stringify(arrayOfProjects));
	}
	//check for length of array before addition
	var oldlength = (JSON.parse(localStorage.getItem('projectList'))).length;
	addProject();
	//check for length of array after addition
	var newlength = (JSON.parse(localStorage.getItem('projectList'))).length;

	//successful if new array contains more entries
	if (newlength > oldlength){
		alert("NEW PROJECT SUCCESSFULLY ADDED");
		window.location.href="newProject.html";
	}
	else alert("failed");
});

//logs project list on load
console.log(localStorage.getItem('projectList'));

//brings you back to catalogue page
document.getElementById('catalogueButton').addEventListener('click', function(){
	window.location.href="popup.html";
});

